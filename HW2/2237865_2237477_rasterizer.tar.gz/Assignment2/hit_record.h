#pragma once

#include "vector3f.h"
#include "vector2f.h"
#include "rotation.h"

namespace fst
{
    struct HitRecord
    {
        math::Vector3f normal;
        float distance;
        int material_id;
        int texture_id;
        int type;
        float radius;
        math::Vector3f center;
        float angle;
        math::Vector3f axis;
    };
}