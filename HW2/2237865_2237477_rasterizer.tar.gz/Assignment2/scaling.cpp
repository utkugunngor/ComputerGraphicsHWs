#include "scaling.h"


namespace fst
{
    Scaling::Scaling(float x, float y, float z)
        : x(x)
        , y(y)
        , z(z)
    {}

    void Scaling::scale(math::Vector3f& vertex){
        vertex.x=vertex.x*x;
        vertex.y=vertex.y*y;
        vertex.z=vertex.z*z;
    }
}
