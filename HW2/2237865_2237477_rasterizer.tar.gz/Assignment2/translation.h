#pragma once
#include "vector3f.h"

namespace fst
{
    class Translation
    {
    public:
        float x, y, z;
        Translation(float x, float y, float z);
        void translate(math::Vector3f& center);
    };
} // namespace fst
