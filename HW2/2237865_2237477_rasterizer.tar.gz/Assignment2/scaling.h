#pragma once
#include "vector3f.h"

namespace fst
{
    class Scaling
    {
    public:
        float x, y, z;
        Scaling(float x, float y, float z);
        void scale(math::Vector3f& vertex);
    };
}
