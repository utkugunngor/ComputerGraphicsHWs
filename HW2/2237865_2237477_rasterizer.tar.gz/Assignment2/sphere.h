#pragma once

#include "vector3f.h"
#include <string>
#include <sstream>
#include <vector>
#include <iostream>
#include "translation.h"
#include "scaling.h"
#include "rotation.h"
#include "texture.h"

namespace fst
{
    class Ray;
    struct HitRecord;

    class Sphere
    {
    public:
        Sphere(int texture_id, const math::Vector3f& center, float radius, int material_id,std::string transformations,float angle,math::Vector3f axis);

        bool intersect(const Ray& ray, HitRecord& hit_record, float max_distance) const;
        bool intersectShadowRay(const Ray& ray, float max_distance) const;
        std::string getTransformations();
        void translateSphere(Translation t);
        void scaleSphere(Scaling s);
        void rotateSphere(Rotation r);
        int getSphereTexture();
        void sphereTexture(Texture texture);
    private:
        int m_texture_id;
        math::Vector3f m_center;
        float m_radius;
        int m_material_id;
        std::string m_transformations;
        float m_angle;
        math::Vector3f m_axis;
    };
}