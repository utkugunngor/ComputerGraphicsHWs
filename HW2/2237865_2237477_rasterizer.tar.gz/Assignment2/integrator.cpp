#include "integrator.h"
#include "image.h"
#include "ctpl_stl.h"
#define M_PI 3.14159265358979323846
#include "string.h"
#include <iostream>
#include <cmath>

namespace fst
{
    Integrator::Integrator(const parser::Scene& parser)
    {
        m_scene.loadFromParser(parser);
    }

    math::Vector3f Integrator::renderPixel(const Ray& ray, int depth) const
    {
        if (depth > m_scene.max_recursion_depth)
        {
            return math::Vector3f(0.0f, 0.0f, 0.0f);
        }

        HitRecord hit_record;
        auto result = m_scene.intersect(ray, hit_record, std::numeric_limits<float>::max());

        if (!result)
        {
            return m_scene.background_color;
        }

        auto& material = m_scene.materials[hit_record.material_id - 1];
        
        auto color = material.get_ambient() * m_scene.ambient_light;
        auto intersection_point = ray.getPoint(hit_record.distance);

        for (auto& light : m_scene.point_lights)
        {
            auto to_light = light.get_position() - intersection_point;
            auto light_pos_distance = math::length(to_light);
            to_light = to_light / light_pos_distance;

            Ray shadow_ray(intersection_point + m_scene.shadow_ray_epsilon * to_light, to_light);

            if (!m_scene.intersectShadowRay(shadow_ray, light_pos_distance))
            {   
               
                if(hit_record.texture_id==0){
                    color = color + light.computeRadiance(light_pos_distance) * material.computeBrdf(to_light, -ray.get_direction(), hit_record.normal);
                }
                else{
                     
                     Texture texture=m_scene.textures[hit_record.texture_id - 1];
                     //std::cout<<texture.getAppereance()<<std::endl;
                     math::Vector2f coords= math::Vector2f(getTextureCoords(hit_record,texture.getWidth(),texture.getHeight(),intersection_point).x,
                                                            getTextureCoords(hit_record,texture.getWidth(),texture.getHeight(),intersection_point).y);
                     
                     char repeat[]="Repeat";
                      char clamp[]="Clamp";   
                         //std::cout<<coords.x<<std::endl;
                     if(!texture.getAppereance().compare(clamp)){
                           // std::cout<<"clamp"<<std::endl;
                            coords=math::clamp(coords,0,1);
                     }
                     else {
                        
                          coords.x= coords.x-floor(coords.x);
                          coords.y= coords.y-floor(coords.y);
                         // std::cout<<coords.x<<std::endl;
                     }


                     float i=coords.x*texture.getWidth();
                     float j=coords.y*texture.getHeight();
                     math::Vector3f tex_color;
                   // std::cout<<coords.y<<std::endl;
                      char nearest[]="nearest";
                      char bilinear[]="bilinear";
                        if(!texture.getInterpolation().compare(nearest)){
                            tex_color= texture.getPixel(round(i),round(j));
                        }
                        else if(!texture.getInterpolation().compare(bilinear)){
                            int p=floor(i);
                            int q=floor(j);
                            float dx=i-p;
                            float dy=j-q;
                            tex_color= texture.getPixel(p,q)*(1-dx)*(1-dy)+texture.getPixel(p+1,q)*dx*(1-dy)+texture.getPixel(p,q+1)*(1-dx)*dy+texture.getPixel(p+1,q+1)*dx*dy;
                             //std::cout<<tex_color.x<<" "<<tex_color.y<<" "<<tex_color.z<<std::endl;
                        }
                     
                        if(!texture.getDecal().compare("replace_kd")){
                            
                            color = color + light.computeRadiance(light_pos_distance) * material.computeWithTex(to_light, -ray.get_direction(), hit_record.normal,0,tex_color);
                            //std::cout<<color.x<<" "<<color.y<<" "<<color.z<<std::endl;
                        }
                        else if(!texture.getDecal().compare("blend_kd")){
                             color = color + light.computeRadiance(light_pos_distance) * material.computeWithTex(to_light, -ray.get_direction(), hit_record.normal,1,tex_color);
                        }
                        else if(!texture.getDecal().compare("replace_all")){
                           // std::cout<<"all"<<std::endl;
                             color = color + light.computeRadiance(light_pos_distance) * material.computeWithTex(to_light, -ray.get_direction(), hit_record.normal,2,tex_color)+tex_color;
                             // std::cout<<color.x<<" "<<color.y<<" "<<color.z<<std::endl;
                            // color=color/255;
                        }
                }
            }
        }

        auto& mirror = material.get_mirror();
        if (mirror.x + mirror.y + mirror.z > 0.0f)
        {
            auto new_direction = math::reflect(ray.get_direction(), hit_record.normal);
            Ray secondary_ray(intersection_point + m_scene.shadow_ray_epsilon * new_direction, new_direction);

            return color + mirror * renderPixel(secondary_ray, depth + 1);
        }
        else
        {
            return color;
        }
    }

    math::Vector2f Integrator::getTextureCoords(HitRecord h,const int width,const int height,math::Vector3f intersection)const{
            float theta,phi,u,v;
           
            if(h.type==0){
                
                float radius=h.radius;
                math::Vector3f center =h.center;

                if(h.angle!=0){
                    intersection=intersection-h.center;
                    rotatePoint(h,intersection);
                    intersection=intersection+h.center;
                }


                 theta=acos((intersection.y-h.center.y)/radius);
                // std::cout<<intersection.y<<" "<<h.center.y<<" "<<radius<<std::endl;
                // 
                 phi= atan2(intersection.z-h.center.z,intersection.x-h.center.x);
                 u=(-phi+M_PI)/(2*M_PI);
                 v=theta/M_PI;
             }

            else if(h.type==1){
                math::Vector3f index = h.axis;
                //std::cout<<"indexes:"<<index.x<<" "<<index.y<<" "<<index.z<<std::endl;
                math::Vector3f v0=m_scene.vertex_data[index.x-1];
                math::Vector3f v1=m_scene.vertex_data[index.y-1];
                math::Vector3f v2=m_scene.vertex_data[index.z-1];
                math::Vector2f uva=m_scene.tex_coord_data[index.x-1];
                math::Vector2f uvb=m_scene.tex_coord_data[index.y-1];
                math::Vector2f uvc=m_scene.tex_coord_data[index.z-1];
                math::Vector3f edge1= v1-v0;
                math::Vector3f edge2= v2-v0;
                math::Vector3f normal= math::cross(edge1, edge2);
                float area= math::length(normal)/2;
                
                math::Vector3f edge3=v2-v1;
                math::Vector3f vp1=intersection-v1;
                math::Vector3f C = math::cross(edge3,vp1);
               
                float alpha=(math::length(C)/2)/area;//((v1.y-v2.y)*(intersection.x-v2.x)+(v2.x-v1.x)*(intersection.y-v2.y))/((v1.y-v2.y)*(v0.x-v2.x)+(v2.x-v1.x)*(v0.y-v2.y));

                 math::Vector3f edge4=v0-v2;
                 math::Vector3f vp2=intersection-v2;
                 C=math::cross(edge4,vp2);

                float beta= (math::length(C)/2)/area;//((v2.y-v0.y)*(intersection.x-v2.x)+(v0.x-v2.x)*(intersection.y-v2.y))/((v1.y-v2.y)*(v0.x-v2.x)+(v2.x-v1.x)*(v0.y-v2.y));
                float gamma= 1-alpha-beta;
               // std::cout<<"bary:"<<alpha<<" "<<beta<<std::endl;

                u=uva.x+beta*(uvb.x-uva.x)+gamma*(uvc.x-uva.x);
                v=uva.y+beta*(uvb.y-uva.y)+gamma*(uvc.y-uva.y);
                //std::cout<<u<<" "<<v<<std::endl;
                
               



            } 
             math::Vector2f uv;
             uv.x=u;
             uv.y=v;
              //std::cout<<h.radius<<std::endl;
           
             return uv;


    }

    void Integrator::rotatePoint(HitRecord hitrecord,math::Vector3f& v) const{
        math::Vector3f r= hitrecord.axis;
         
        float distance=sqrt(r.x*r.x+r.y*r.y+r.z*r.z);
        //std::cout<<distance<<std::endl;
        int a=r.x/distance;
        int b=r.y/distance;
        int c=r.z/distance;
        int d=sqrt(b*b+c*c);
        float radyan=hitrecord.angle*M_PI/180;
        float new_x,new_y,new_z;

        //RX
       if(d!=0){
        new_x=v.x;
        new_y=v.y*(c/d)-v.z*(b/d);
        new_z=v.y*(b/d)+v.z*(c/d);
        v.x=new_x;
        v.y=new_y;
        v.z=new_z;
       }
        
        //RY
        new_x=v.x*d-a*v.z;
        new_y=v.y;
        new_z=v.x*a+v.z*d;
        v.x=new_x;
        v.y=new_y;
        v.z=new_z;
        //RZ
        
        new_x=v.x*cos(-radyan)-v.y*sin(-radyan);
         //std::cout<<"x:"<<v.x<<"*"<<cos(radyan)<<"-"<<v.y<<"*"<<sin(radyan)<<"="<<new_x<<std::endl;
        new_y=v.x*sin(-radyan)+v.y*cos(-radyan);
        v.z=v.z;
        v.x=new_x;
        v.y=new_y;
        //-RY
        new_x=v.x*d+a*v.z;
        new_y=v.y;
        new_z=-v.x*a+v.z*d;
        v.z=new_z;
        v.x=new_x;
        v.y=new_y;
        //-RX
         if(d!=0){
        new_x=v.x;
        new_y=v.y*(c/d)+v.z*(b/d);
        new_z=-v.y*(b/d)+v.z*(c/d);
        v.z=new_z;
        v.x=new_x;
        v.y=new_y;
         }



    }


    void Integrator::integrate() const
    {
        for (auto& camera : m_scene.cameras)
        {
            auto& resolution = camera.get_screen_resolution();
            Image image(resolution.x, resolution.y);

            ctpl::thread_pool pool(128);
            for (int i = 0; i < resolution.x; ++i)
            {
                pool.push([i, &resolution, &camera, &image, this](int id) {
                    for (int j = 0; j < resolution.y; ++j)
                    {
                        auto ray = camera.castPrimayRay(static_cast<float>(i), static_cast<float>(j));
                        auto color = renderPixel(ray, 0);
                        image.setPixel(i, j, math::clamp(color, 0.0f, 255.0f));
                    }
                });
            }
            pool.stop(true);

            image.save(camera.get_image_name());
        }
    }

    void Integrator::maketransform(){

        m_scene.transform();

    }
}
