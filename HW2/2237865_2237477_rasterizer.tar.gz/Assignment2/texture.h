#pragma once
#include <string>
#include "vector3f.h"

namespace fst
{
    class Texture
    {
    public:
        Texture();
        Texture(int width,
                int height,
                unsigned char *image,
                std::string imageName,
                std::string interpolation,
                std::string decalMode,
                std::string appearance);
        int getWidth() const;
        int getHeight() const;     
        std::string getDecal();
        std::string  getInterpolation();
        std::string getAppereance();
        math::Vector3f getPixel(int i,int j);   

    private:
        int m_width;
        int m_height;
        unsigned char *m_image;
        std::string m_imageName;
        std::string m_interpolation;
        std::string m_decalMode;
        std::string m_appearance;
    };
}