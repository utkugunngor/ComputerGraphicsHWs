#include "translation.h"
#include "vector3f.h"

namespace fst
{
    Translation::Translation(float x, float y, float z)
        : x(x), y(y), z(z)
    {
    }

    void Translation::translate(math::Vector3f& center){
        center.x += x;
        center.y += y;
        center.z += z;
    }
} // namespace fst
