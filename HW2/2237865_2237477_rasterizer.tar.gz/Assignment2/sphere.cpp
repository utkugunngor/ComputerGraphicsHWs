#include "sphere.h"
#include "hit_record.h"
#include "ray.h"
#include "translation.h"
#include "texture.h"
#include <cmath>
#define M_PI 3.14159265358979323846

namespace fst
{
    Sphere::Sphere(int texture_id, const math::Vector3f& center, float radius, int material_id,std::string transformations,float angle,math::Vector3f axis)
        : m_texture_id(texture_id)
        , m_center(center)
        , m_radius(radius)
        , m_material_id(material_id)
        , m_transformations(transformations)
        ,m_angle(angle)
        ,m_axis(axis)
    {}

    bool Sphere::intersect(const Ray& ray, HitRecord& hit_record, float max_distance) const
    {
        //geometrical approach
        auto e = m_center - ray.get_origin();
        auto a = math::dot(e, ray.get_direction());
        auto x = m_radius * m_radius + a * a - math::dot(e, e);
     

        if (x < 0.0f)
        {
            return false;
        }
        auto distance = a - sqrtf(x);
        if(math::length(e)<m_radius) distance = a + sqrtf(x);
         
        
        if (distance > 0.0f && distance < max_distance)
        {
            //Fill the intersection record.
            hit_record.distance = distance;
            hit_record.normal = math::normalize(ray.getPoint(hit_record.distance) - m_center);
            hit_record.material_id = m_material_id;
            hit_record.texture_id=m_texture_id;
            hit_record.type=0;
            hit_record.radius=m_radius;
            hit_record.angle=m_angle;
            hit_record.axis=m_axis;
            hit_record.center=m_center;
            

            return true;
        }
        return false;
    }

    int Sphere::getSphereTexture(){return m_texture_id;}

    bool Sphere::intersectShadowRay(const Ray& ray, float max_distance) const
    {
        //geometrical approach
        auto e = m_center - ray.get_origin();
        auto a = math::dot(e, ray.get_direction());
        auto x = m_radius * m_radius + a * a - math::dot(e, e);

        if (x < 0.0f)
        {
            return false;
        }

        auto distance = a - sqrtf(x);
        return distance > 0.0f && distance < max_distance;
    }

    void Sphere::translateSphere(Translation t){
        t.translate(m_center);
    }

    std::string Sphere::getTransformations(){
        return m_transformations;
    }
    void Sphere::scaleSphere(Scaling s){
        m_radius=m_radius*s.x;
        m_center.x=m_center.x*s.x;
        m_center.y=m_center.y*s.y;
        m_center.z=m_center.z*s.z;
    }

    void Sphere::rotateSphere(Rotation r){
        m_angle=r.angle;
        m_axis=math::Vector3f(r.x,r.y,r.z);
    }

   

    
}