#include "scene.h"
#include <iomanip>
#include "ppm.h"
#include "jpeg.h"

namespace fst
{
    void Scene::loadFromParser(const parser::Scene& parser)
    {
        for (auto& camera : parser.cameras)
        {
            cameras.push_back(Camera(
                math::Vector3f(camera.position.x, camera.position.y, camera.position.z),
                math::Vector3f(camera.gaze.x, camera.gaze.y, camera.gaze.z),
                math::Vector3f(camera.up.x, camera.up.y, camera.up.z),
                math::Vector4f(camera.near_plane.x, camera.near_plane.y, camera.near_plane.z, camera.near_plane.w),
                math::Vector2f(camera.image_width, camera.image_height),
                camera.image_name,
                camera.near_distance));
        }

        for (auto& pointlight : parser.point_lights)
        {
            point_lights.push_back(PointLight(
                math::Vector3f(pointlight.position.x, pointlight.position.y, pointlight.position.z),
                math::Vector3f(pointlight.intensity.x, pointlight.intensity.y, pointlight.intensity.z)));
        }

        for (auto& material : parser.materials)
        {
            materials.push_back(Material(
                math::Vector3f(material.ambient.x, material.ambient.y, material.ambient.z),
                math::Vector3f(material.diffuse.x, material.diffuse.y, material.diffuse.z),
                math::Vector3f(material.specular.x, material.specular.y, material.specular.z),
                math::Vector3f(material.mirror.x, material.mirror.y, material.mirror.z),
                material.phong_exponent));
        }

        for (auto &translation : parser.translations)
        {
            translations.push_back(
                Translation(translation.x, translation.y, translation.z));
        }

        for (auto &scaling : parser.scalings)
        {
            scalings.push_back(
                Scaling(scaling.x, scaling.y, scaling.z));
        }

        for (auto &rotation : parser.rotations)
        {
            rotations.push_back(
                Rotation(rotation.angle, rotation.x, rotation.y, rotation.z));
        }

        for (auto& vertex : parser.vertex_data)
        {
            vertex_data.push_back(math::Vector3f(vertex.x, vertex.y, vertex.z));
        }

        for (auto& tex_coord : parser.tex_coord_data)
        {
            tex_coord_data.push_back(math::Vector2f(tex_coord.x, tex_coord.y));
        }

        for (auto& mesh : parser.meshes)
        {
            std::vector<Triangle> triangles;
            for (auto& face : mesh.faces)
            {
                triangles.push_back(Triangle(
                    vertex_data[face.v0_id - 1],
                    vertex_data[face.v1_id - 1],
                    vertex_data[face.v2_id - 1],
                    vertex_data[face.v1_id - 1] - vertex_data[face.v0_id - 1],
                    vertex_data[face.v2_id - 1] - vertex_data[face.v0_id - 1],math::Vector3f(face.v0_id,face.v1_id,face.v2_id),mesh.texture_id));
            }

            meshes.push_back(Mesh(std::move(triangles), mesh.material_id,mesh.transformations,mesh.texture_id));
        }

        for (auto& triangle : parser.triangles)
        {
            std::vector<Triangle> triangles;

            triangles.push_back(Triangle(
                vertex_data[triangle.indices.v0_id - 1],
                vertex_data[triangle.indices.v1_id - 1],
                vertex_data[triangle.indices.v2_id - 1],
                vertex_data[triangle.indices.v1_id - 1] - vertex_data[triangle.indices.v0_id - 1],
                vertex_data[triangle.indices.v2_id - 1] - vertex_data[triangle.indices.v0_id - 1],math::Vector3f(triangle.indices.v0_id,triangle.indices.v1_id,triangle.indices.v2_id),triangle.texture_id));

            meshes.push_back(Mesh(std::move(triangles), triangle.material_id,triangle.transformations,triangle.texture_id));
        }

        for (auto& sphere : parser.spheres)
        {
            spheres.push_back(Sphere(sphere.texture_id,vertex_data[sphere.center_vertex_id - 1],
                sphere.radius, sphere.material_id,sphere.transformations,0,math::Vector3f(0,0,0)));
        }

        for(auto& texture : parser.textures){
            int w, h;

            read_jpeg_header((char*)texture.imageName.c_str(), w, h);
            unsigned char* jpegImage = new unsigned char [w * h * 3];
            read_jpeg((char*)texture.imageName.c_str(), jpegImage, w, h);
            textures.push_back(Texture(w, h, jpegImage, texture.imageName, texture.interpolation, texture.decalMode, texture.appearance));
        }

        background_color = math::Vector3f(parser.background_color.x, parser.background_color.y, parser.background_color.z);
        ambient_light = math::Vector3f(parser.ambient_light.x, parser.ambient_light.y, parser.ambient_light.z);
        shadow_ray_epsilon = parser.shadow_ray_epsilon;
        max_recursion_depth = parser.max_recursion_depth;
    }

    bool Scene::intersect(const Ray& ray, HitRecord& hit_record, float max_distance) const
    {
        HitRecord temp;
        float min_distance = max_distance;
        for (auto& sphere : spheres)
        {
            if (sphere.intersect(ray, temp, min_distance))
            {
                min_distance = temp.distance;
                hit_record = temp;
            }
        }

        for (auto& mesh : meshes)
        {
            if (mesh.intersect(ray, temp, min_distance))
            {
                min_distance = temp.distance;
                hit_record = temp;
            }
        }

        return min_distance != max_distance;
    }

    bool Scene::intersectShadowRay(const Ray& ray, float max_distance) const
    {
        for (auto& sphere : spheres)
        {
            if (sphere.intersectShadowRay(ray, max_distance))
            {
                return true;
            }
        }


        for (auto& mesh : meshes)
        {
            if (mesh.intersectShadowRay(ray, max_distance))
            {
		return true;
            }
        }

	return false;
    }
    void Scene::transform(){

        for (auto& sphere : spheres)
        {
            
            std::vector<std::string> result=parseString(sphere.getTransformations());
            int size=result.size();
            if(size==0) break;
            for(int i=0;i<size;i++){
              
                if(result[i][0]=='t'){
                    std::string id=result[i].substr(1,result[i].size()-1);
                    int ide=stoi(id);
                    Translation t=translations[ide-1];
                   
                    sphere.translateSphere(t);
                    
                }
                else if(result[i][0]=='s'){
                    std::string id=result[i].substr(1,result[i].size()-1);
                    int ide=stoi(id);
                    Scaling coords=scalings[ide-1];  
                    
                    sphere.scaleSphere(coords);             

                }

                else if(result[i][0]=='r'){
                    std::string id=result[i].substr(1,result[i].size()-1);
                    int ide=stoi(id);
                    Rotation coords=rotations[ide-1];      
                    sphere.rotateSphere(coords);            

                }
                
            }
        }
      

         for (auto& mesh : meshes)
        {
          
            std::vector<std::string> result=parseString(mesh.getTransformations());
            int size=result.size();
            for(int i=0;i<size;i++){

                if(result[i][0]=='t'){
                    std::string id=result[i].substr(1,result[i].size()-1);
                    int ide=stoi(id);
                    Translation coords=translations[ide-1];
                   
                    mesh.translateMesh(coords);
                    
                }
                else if(result[i][0]=='s'){
                    std::string id=result[i].substr(1,result[i].size()-1);
                    int ide=stoi(id);
                    Scaling coords=scalings[ide-1]; 
                    mesh.scaleMesh(coords);                 

                }

                else if(result[i][0]=='r'){
                    std::string id=result[i].substr(1,result[i].size()-1);
                    int ide=stoi(id);
                    Rotation coords=rotations[ide-1];    
                    //std::cout<<"in scene"<<std::endl; 
                    mesh.rotateMesh(coords);             

                }
                
            }
        }


    }

    std::vector<std::string> Scene::parseString( std::string s){
       
        std::vector<std::string> result; 
        std::istringstream ss(s); 
        std::string word;
        while (ss >> word) 
        {
            result.push_back(word); 
            
  
        }    
        return result;    
    }

    

    
}
