#include "texture.h"
#include <string>
#include <iostream>

namespace fst
{
  Texture::Texture() {}
  Texture::Texture(int width,
                   int height,
                   unsigned char *image,
                   std::string imageName,
                   std::string interpolation,
                   std::string decalMode,
                   std::string appearance)
      : m_width(width),
        m_height(height),
        m_image(image),
        m_imageName(imageName),
        m_interpolation(interpolation),
        m_decalMode(decalMode),
        m_appearance(appearance)
  {
  }
   std::string Texture::getDecal(){ return m_decalMode;}
   std::string Texture::getInterpolation(){return m_interpolation;}
   std::string Texture::getAppereance(){ return m_appearance;}
   math::Vector3f Texture::getPixel(int i,int j){
      if(j>m_height-1) j=j-1;
      if(i>m_width-1) i=i-1;
     // std::cout<<i<<" "<<j<<std::endl;
     // std::cout<<m_width<<" "<<m_height<<std::endl;
      return math::Vector3f(m_image[3*(j*m_width+i)],m_image[3*(j*m_width+i)+1],m_image[3*(j*m_width+i)+2]); 
      }
   int Texture::getWidth() const{
     return m_width;
   }
   int Texture::getHeight() const{
      return m_height;
        }
} // namespace fst