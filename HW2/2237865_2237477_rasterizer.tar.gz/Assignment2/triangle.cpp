#include "hit_record.h"
#include "triangle.h"
#include "ray.h"
#include "math.h"
#include <iostream>
#define M_PI 3.14159265358979323846

namespace fst
{
    Triangle::Triangle(const math::Vector3f& v0,const math::Vector3f& v1,const math::Vector3f& v2, const math::Vector3f& edge1, const math::Vector3f& edge2,math::Vector3f indexes,int texture_id)
        : m_v0(v0)
        ,m_v1(v1)
        ,m_v2(v2)
        , m_edge1(edge1)
        , m_edge2(edge2)
        , m_normal(math::normalize(math::cross(edge1, edge2)))
        ,m_indexes(indexes)
        ,m_texture_id(texture_id)
    {}

    bool Triangle::intersect(const Ray& ray, HitRecord& hit_record, float max_distance) const
    {
        //M�ller-Trumbore algorithm
        auto pvec = math::cross(ray.get_direction(), m_edge2);
        auto inv_det = 1.0f / math::dot(m_edge1, pvec);

        auto tvec = ray.get_origin() - m_v0;
        auto w1 = math::dot(tvec, pvec) * inv_det;

        if (w1 < 0.0f || w1 > 1.0f)
        {
            return false;
        }

        auto qvec = math::cross(tvec, m_edge1);
        auto w2 = math::dot(ray.get_direction(), qvec) * inv_det;

        if (w2 < 0.0f || (w1 + w2) > 1.0f)
        {
            return false;
        }

        auto distance = math::dot(m_edge2, qvec) * inv_det;
        if (distance > 0.0f && distance < max_distance)
        {
            //Fill the intersection record.
            hit_record.normal = m_normal;
            hit_record.distance = distance;

            return true;
        }
        return false;
    }

    bool Triangle::intersectShadowRay(const Ray& ray, float max_distance) const
    {
        //M�ller-Trumbore algorithm
        auto pvec = math::cross(ray.get_direction(), m_edge2);
        auto inv_det = 1.0f / math::dot(m_edge1, pvec);

        auto tvec = ray.get_origin() - m_v0;
        auto w1 = math::dot(tvec, pvec) * inv_det;

        if (w1 < 0.0f || w1 > 1.0f)
        {
            return false;
        }

        auto qvec = math::cross(tvec, m_edge1);
        auto w2 = math::dot(ray.get_direction(), qvec) * inv_det;

        if (w2 < 0.0f || (w1 + w2) > 1.0f)
        {
            return false;
        }

        auto distance = math::dot(m_edge2, qvec) * inv_det;
        return distance > 0.0f && distance < max_distance;
    }


    math::Vector3f Triangle::getIndexes() const {return m_indexes;}

    void Triangle::translateTriangle(Translation t){
        t.translate(m_v0);
        t.translate(m_v1);
        t.translate(m_v2);
        m_edge1=m_v1-m_v0;
        m_edge2=m_v2-m_v0;
        m_normal=math::normalize(math::cross(m_edge1, m_edge2));
    }

    math::Vector3f Triangle::calculatecenter(){
        
        return math::Vector3f((m_v0.x+m_v1.x+m_v2.x)/3,(m_v0.y+m_v1.y+m_v2.y)/3,(m_v0.z+m_v1.z+m_v2.z)/3);
    }

    void Triangle::scaleTriangle(Scaling s,math::Vector3f center){
        
      //  math::Vector3f center=math::Vector3f((m_v0.x+v_1.x+v_2.x)/3,(m_v0.y+m_v1.y+m_v2.y)/3,(m_v0.z+m_v1.z+m_v2.z)/3);
        Translation t=Translation(-center.x,-center.y,-center.z);
       // math::Vector3f v1=m_edge1+m_v0;
        //math::Vector3f v2=m_edge2+m_v0;
        
        t.translate(m_v0);
        t.translate(m_v1);
        t.translate(m_v2);
        //std::cout<<"aftert:"<<" "<<m_v1.x<<" "<<m_v1.y<<" "<<m_v1.z<<std::endl;
        s.scale(m_v0);
        s.scale(m_v1);
        s.scale(m_v2);
        t=Translation(center.x,center.y,center.z);
        //std::cout<<"afters:"<<" "<<m_v1.x<<" "<<m_v1.y<<" "<<m_v1.z<<std::endl;
        t.translate(m_v0);
        t.translate(m_v1);
        t.translate(m_v2);
        //std::cout<<"aftert:"<<" "<<m_v1.x<<" "<<m_v1.y<<" "<<m_v1.z<<std::endl;
        m_edge1=m_v1-m_v0;
        m_edge2=m_v2-m_v0;
        m_normal=math::normalize(math::cross(m_edge1, m_edge2));
        //Scaling z=Scaling(1/s.x,1/s.y,1/s.z); TRANSFORMING NORMALS????
    }

    void Triangle::rotateTriangle(Rotation r){
        // std::cout<<"before:"<<m_v0.x<<" "<<m_v0.y<<" "<<m_v0.z<<std::endl;
        rotateVertex(r,m_v0);
        //std::cout<<"after:"<<m_v0.x<<" "<<m_v0.y<<" "<<m_v0.z<<std::endl;
        rotateVertex(r,m_v1);
        rotateVertex(r,m_v2);
        m_edge1=m_v1-m_v0;
        m_edge2=m_v2-m_v0;
        m_normal=math::normalize(math::cross(m_edge1, m_edge2));
    }

    void Triangle::rotateVertex(Rotation r,math::Vector3f& v){
        float distance=sqrt(r.x*r.x+r.y*r.y+r.z*r.z);
        int a=r.x/distance;
        int b=r.y/distance;
        int c=r.z/distance;
        int d=sqrt(b*b+c*c);
        float radyan=r.angle*M_PI/180;
        float new_x,new_y,new_z;

        //RX
        new_x=v.x;
        new_y=v.y*(c/d)-v.z*(b/d);
        new_z=v.y*(b/d)+v.z*(c/d);
        v.x=new_x;
        v.y=new_y;
        v.z=new_z;
        //RY
        new_x=v.x*d-a*v.z;
        new_y=v.y;
        new_z=v.x*a+v.z*d;
        v.x=new_x;
        v.y=new_y;
        v.z=new_z;
        //RZ
        
        new_x=v.x*cos(radyan)-v.y*sin(radyan);
         //std::cout<<"x:"<<v.x<<"*"<<cos(radyan)<<"-"<<v.y<<"*"<<sin(radyan)<<"="<<new_x<<std::endl;
        new_y=v.x*sin(radyan)+v.y*cos(radyan);
        v.z=v.z;
        v.x=new_x;
        v.y=new_y;
        //-RY
        new_x=v.x*d+a*v.z;
        new_y=v.y;
        new_z=-v.x*a+v.z*d;
        v.z=new_z;
        v.x=new_x;
        v.y=new_y;
        //-RX
        new_x=v.x;
        new_y=v.y*(c/d)+v.z*(b/d);
        new_z=-v.y*(b/d)+v.z*(c/d);
        v.z=new_z;
        v.x=new_x;
        v.y=new_y;
    }
}
