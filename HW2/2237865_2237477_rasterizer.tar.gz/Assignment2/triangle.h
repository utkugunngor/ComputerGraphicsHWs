#pragma once

#include "triangular.h"
#include "vector3f.h"
#include "translation.h"
#include "scaling.h"
#include "rotation.h"
#include <cmath>

namespace fst
{
    class Ray;
    struct HitRecord;

    class Triangle : public Triangular
    {
    public:
        Triangle(const math::Vector3f& v0,const math::Vector3f& v1,const math::Vector3f& v2, const math::Vector3f& edge1, const math::Vector3f& edge2,math::Vector3f indexes,int texture_id);

        bool intersect(const Ray& ray, HitRecord& hit_record, float max_distance) const override;
        bool intersectShadowRay(const Ray& ray, float max_distance) const override;
        void translateTriangle(Translation t);
        void scaleTriangle(Scaling s,math::Vector3f center);
        math::Vector3f calculatecenter();
        void rotateTriangle(Rotation r);
        void rotateVertex(Rotation r,math::Vector3f& v);
        math::Vector3f getIndexes() const;

    private:
        math::Vector3f m_v0,m_v1,m_v2, m_edge1, m_edge2;
        math::Vector3f m_normal;
         math::Vector3f m_indexes;
         int m_texture_id;
    };
}
