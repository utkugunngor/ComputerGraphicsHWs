#pragma once

#include "scene.h"

namespace fst
{
    class Integrator
    {
    public:
        Integrator(const parser::Scene& parser);

        math::Vector3f renderPixel(const Ray& ray, int depth) const;
        void integrate() const;
        void maketransform();
         math::Vector2f getTextureCoords(HitRecord h,const int width,const int height,math::Vector3f intersection) const;
         void rotatePoint(HitRecord hitrecord,math::Vector3f& intersectionpoint)const;

    private:
        Scene m_scene;
    };
}